g++ -std=c++11  -I ./eigen main.cpp -o main 
g++ -std=c++11  -I ./eigen ejemplo.cpp -o ejemplo
